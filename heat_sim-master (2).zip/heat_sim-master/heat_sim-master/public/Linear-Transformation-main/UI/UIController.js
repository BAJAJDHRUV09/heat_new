// Global object to store all necessary data about LT;
const LinearTransformationData = {
    BasisVec1:  new Array(2).fill(0),
    BasisVec2:  new Array(2).fill(0),
    Matrix:     new Array(2).fill().map(() => Array(2).fill(0)),
};

// Fixed standard basis vectors - these won't change
LinearTransformationData.BasisVec1[0] = 1;
LinearTransformationData.BasisVec1[1] = 0;

LinearTransformationData.BasisVec2[0] = 0;
LinearTransformationData.BasisVec2[1] = 1;

// Default values for the transformation matrix (identity matrix)
LinearTransformationData.Matrix[0][0] = 1;
LinearTransformationData.Matrix[0][1] = 0;
LinearTransformationData.Matrix[1][0] = 0;
LinearTransformationData.Matrix[1][1] = 1;

const AnimationData = {
    IsPlaying : false,
    Val : 0.0 // [0 -> 1];
};

const ConfigurationsData = {
    displayEigenVectors : false,

    displayInOutVector : false,
    InOutVector : new Array(2).fill(0)
};

// Handle Matrix inputs - these will control the transformation matrix
const matrixValHandlers = {
    row1col1: (val) => {
        // assign to obj
        console.log(`Matrix value from row 1 col 1  : ${val}`);

        let valu = parseFloat(val);
        if(Number.isNaN(valu)) valu = 1;
        LinearTransformationData.Matrix[0][0] = valu;
        console.log("Updated Matrix[0][0] to:", valu);
        console.log("Current matrix:", LinearTransformationData.Matrix);
    },
    
    row1col2: (val) => {
        // assign to obj

        let valu = parseFloat(val);
        if(Number.isNaN(valu)) valu = 0;
        LinearTransformationData.Matrix[0][1] = valu;

        console.log(`Matrix value from row 1 col 2 : ${val}`);
        console.log("Updated Matrix[0][1] to:", valu);
        console.log("Current matrix:", LinearTransformationData.Matrix);
    },
    
    row2col1: (val) => {
        // assign to obj
        console.log(`Matrix value from row 2 col 1 : ${val}`);

        let valu = parseFloat(val);
        if(Number.isNaN(valu)) valu = 0;
        LinearTransformationData.Matrix[1][0] = valu;
        console.log("Updated Matrix[1][0] to:", valu);
        console.log("Current matrix:", LinearTransformationData.Matrix);
    },
    
    row2col2: (val) => {
        // assign to obj
        console.log(`Matrix value from row 2 col 2 : ${val}`);

        let valu = parseFloat(val);
        if(Number.isNaN(valu)) valu = 1;
        LinearTransformationData.Matrix[1][1] = valu;
        console.log("Updated Matrix[1][1] to:", valu);
        console.log("Current matrix:", LinearTransformationData.Matrix);
    }
}

const trVectorValHandlers = {
    vec1val1: (val) => {
        // assign to obj
        console.log(`Value from first tr vector first val is : ${val}`);

        let valu = parseFloat(val);
        if(Number.isNaN(valu)) valu = 0;
        ConfigurationsData.InOutVector[0] = valu;
        // LinearTransformationData.BasisVec1[0] = parseInt(val);
    },

    vec1val2: (val) => {
        // assign to obj
        console.log(`Value from first tr vector second val is : ${val}`);

        let valu = parseFloat(val);
        if(Number.isNaN(valu)) valu = 0;
        ConfigurationsData.InOutVector[1] = valu;
        // LinearTransformationData.BasisVec1[1] = parseInt(val);
    },
};

// Function to setup event listeners
function setupEventListeners() {
    console.log("Setting up event listeners...");
    
    // Only keep event listeners for matrix-inputs (transformation matrix)
    const matrixInputs = document.getElementsByClassName("matrix-input");
    console.log("Found matrix inputs:", matrixInputs.length);
    
    if (matrixInputs.length === 0) {
        console.log("No matrix inputs found, retrying in 100ms...");
        setTimeout(setupEventListeners, 100);
        return;
    }
    
    matrixInputs.forEach((domElement, index) => {
        console.log(`Setting up listener for matrix input ${index}:`, domElement.getAttribute("data-identifier"));
        domElement.addEventListener("input", (e) => {
            const identifier = e.target.getAttribute("data-identifier");
            console.log(`Matrix input changed: ${identifier} = ${e.target.value}`);
            matrixValHandlers[identifier](e.target.value);
        });
        
        // Also add change event for better compatibility
        domElement.addEventListener("change", (e) => {
            const identifier = e.target.getAttribute("data-identifier");
            console.log(`Matrix input changed (change event): ${identifier} = ${e.target.value}`);
            matrixValHandlers[identifier](e.target.value);
        });
    });
    
    console.log("Event listeners setup complete!");
    
    // Add test button functionality
    const testButton = document.getElementById("testMatrix");
    if (testButton) {
        testButton.addEventListener("click", () => {
            const status = document.getElementById("matrixStatus");
            const matrix = LinearTransformationData.Matrix;
            status.textContent = `Matrix: [${matrix[0][0]}, ${matrix[0][1]}; ${matrix[1][0]}, ${matrix[1][1]}]`;
            console.log("Current matrix:", matrix);
        });
    }
}

// Setup event listeners when DOM is ready
if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', setupEventListeners);
} else {
    // DOM is already ready
    setupEventListeners();
}

// Make these available globally for the export.js to work
window.LinearTransformationData = LinearTransformationData;
window.AnimationData = AnimationData;
window.ConfigurationsData = ConfigurationsData;





