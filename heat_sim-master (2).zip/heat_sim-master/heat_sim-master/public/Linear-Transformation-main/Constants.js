const Constants = {
    UNIT_LENGTH : 60
};

export {
    Constants
};
